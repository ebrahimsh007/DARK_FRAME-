// editor.js

const editor = CodeMirror(document.getElementById("editor"), {
  lineNumbers: true,
  mode: "javascript",
  theme: "material-darker",
  autoCloseBrackets: true,
  matchBrackets: true,
  lineWrapping: true,
});

document.getElementById("run").addEventListener("click", () => {
  const output = document.getElementById("output");
  const code = editor.getValue();

  try {
    output.innerText = eval(code);
  } catch (err) {
    output.innerText = err;
  }
});