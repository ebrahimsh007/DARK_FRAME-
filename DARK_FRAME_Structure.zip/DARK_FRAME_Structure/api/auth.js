// تسجيل الدخول وتسجيل مستخدم جديد
const express = require('express');
const router = express.Router();

// تسجيل
router.post('/register', (req, res) => {
  const { username, password } = req.body;
  res.status(200).json({ message: 'تم التسجيل بنجاح', username });
});

// تسجيل دخول
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  res.status(200).json({ message: 'تم تسجيل الدخول', token: 'fake-token-123' });
});

module.exports = router;