// عرض المشاريع الخاصة بالمستخدم
const express = require('express');
const router = express.Router();

// بيانات تجريبية
const projects = [
  { id: 1, name: 'مشروعي الأول', description: 'وصف المشروع الأول' },
  { id: 2, name: 'مشروعي الثاني', description: 'وصف المشروع الثاني' }
];

router.get('/', (req, res) => {
  res.json(projects);
});

module.exports = router;