// بيانات المستخدم
const express = require('express');
const router = express.Router();

// بيانات تجريبية
const users = [
  { id: 1, name: 'مستخدم 1', email: 'user1@example.com' },
  { id: 2, name: 'مستخدم 2', email: 'user2@example.com' }
];

router.get('/', (req, res) => {
  res.json(users);
});

module.exports = router;